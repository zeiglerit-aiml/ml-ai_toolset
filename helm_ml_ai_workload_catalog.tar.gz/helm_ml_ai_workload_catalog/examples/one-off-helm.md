# One-off Helm installs

Python API:

```bash
helm upgrade --install api   ./charts/python-api   --namespace apps   --create-namespace   --set image.repository=REGISTRY/api   --set image.tag=1.0
```

Jupyter:

```bash
helm upgrade --install notebook   ./charts/jupyter-workbench   --namespace ml   --create-namespace   --set image.repository=REGISTRY/jupyter-ml-workbench   --set image.tag=1.0
```

ML inference:

```bash
helm upgrade --install risk-api   ./charts/ml-inference   --namespace ml   --create-namespace   --set image.repository=REGISTRY/risk-api   --set image.tag=1.0
```

Training:

```bash
helm upgrade --install training   ./charts/training-job   --namespace ml   --create-namespace
```

vLLM:

```bash
helm upgrade --install vllm   ./charts/vllm-serving   --namespace ai   --create-namespace   --set model.name=YOUR_MODEL_NAME
```
