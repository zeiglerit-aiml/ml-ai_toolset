# Helm ML/AI Workload Catalog

Reusable Helm charts for deploying common Python, ML, AI, Jupyter, training, and LLM workloads onto an existing Kubernetes cluster.

This repo assumes your separate infrastructure repo already created:

- EKS / AKS / GKE
- container registry
- Kubernetes access
- storage classes
- GPU nodes when needed
- workload identity / IAM
- optional Vault / OPA / observability

## Use patterns

### One-off Helm

```bash
helm upgrade --install risk-api \
  ./charts/ml-inference \
  --namespace ml \
  --create-namespace \
  --set image.repository=YOUR_REGISTRY/risk-api \
  --set image.tag=1.0
```

### Ansible selector

```bash
ansible-playbook \
  ansible/install-chart.yml \
  -e chart=ml-inference \
  -e release_name=risk-api \
  -e namespace=ml \
  -e image_repository=YOUR_REGISTRY/risk-api \
  -e image_tag=1.0
```

### Umbrella Helm chart

```bash
helm dependency update charts/ai-ml-platform

helm upgrade --install ai-stack \
  ./charts/ai-ml-platform \
  --namespace ai \
  --create-namespace \
  -f charts/ai-ml-platform/values-demo.yaml
```

## Catalog

```text
charts/
├── python-api/
├── ml-inference/
├── multimodel-serving/
├── jupyter-workbench/
├── training-job/
├── scheduled-training/
├── pytorch-gpu/
├── vllm-serving/
├── agentic-rag/
├── angular-frontend/
└── ai-ml-platform/
```

## GitOps model

```text
GitHub Actions
    |
    +--> test
    +--> build image
    +--> push registry
    +--> update Git values
             |
             v
          Argo CD
             |
             v
            Helm
             |
             v
       EKS / AKS / GKE
```

For manual development/testing, use Helm or Ansible directly.

For production GitOps, let Argo CD reconcile the same charts.

## Ansible chart list

```bash
ansible-playbook ansible/install-chart.yml \
  -e list_charts=true
```

## Argo CD

Examples:

```text
argocd/jupyter-workbench.application.yaml
argocd/ai-ml-platform.application.yaml
```

Update the repo URL, image repositories, and model names before applying.
