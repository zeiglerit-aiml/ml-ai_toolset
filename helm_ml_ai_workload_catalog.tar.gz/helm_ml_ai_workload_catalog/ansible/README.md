# Ansible chart installer

List:

```bash
ansible-playbook ansible/install-chart.yml   -e list_charts=true
```

Install Jupyter:

```bash
ansible-playbook ansible/install-chart.yml   -e chart=jupyter-workbench   -e release_name=ml-workbench   -e namespace=ml   -e image_repository=REGISTRY/jupyter-ml-workbench   -e image_tag=1.0
```

Install vLLM:

```bash
ansible-playbook ansible/install-chart.yml   -e chart=vllm-serving   -e release_name=vllm   -e namespace=ai
```

Install umbrella chart:

```bash
ansible-playbook ansible/install-chart.yml   -e chart=ai-ml-platform   -e release_name=ai-stack   -e namespace=ai   -e values_file=charts/ai-ml-platform/values-demo.yaml
```
