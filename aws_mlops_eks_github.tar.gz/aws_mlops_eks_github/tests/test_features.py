import pandas as pd
from pipeline.features.build import build_features


def test_build_features():
    rows = []
    for i in range(20):
        rows.append({
            "age": 20 + i,
            "income": 50000 + i * 1000,
            "transactions": i + 1,
            "credit_score": 600 + i,
            "label": i % 2,
        })
    df = pd.DataFrame(rows)
    X_train, X_test, y_train, y_test = build_features(df)
    assert len(X_train) + len(X_test) == 20
    assert len(y_train) + len(y_test) == 20
