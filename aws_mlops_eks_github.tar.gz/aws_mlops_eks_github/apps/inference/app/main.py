from __future__ import annotations

import os
from pathlib import Path

import boto3
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

MODEL_PATH = Path(os.getenv("MODEL_PATH", "/models/model.joblib"))
MODEL_BUCKET = os.getenv("MODEL_BUCKET")
MODEL_KEY = os.getenv("MODEL_KEY", "models/document-risk-classifier/model.joblib")

app = FastAPI(title="Document Risk ML Endpoint", version="1.0.0")
model = None


class PredictionRequest(BaseModel):
    age: float = Field(ge=0, le=120)
    income: float = Field(ge=0)
    transactions: float = Field(ge=0)
    credit_score: float = Field(ge=0, le=900)


class PredictionResponse(BaseModel):
    prediction: int
    probability: float
    model: str = "document-risk-classifier"


def download_model() -> None:
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    if MODEL_BUCKET:
        boto3.client("s3").download_file(MODEL_BUCKET, MODEL_KEY, str(MODEL_PATH))


@app.on_event("startup")
def load_model() -> None:
    global model
    if not MODEL_PATH.exists():
        download_model()
    if MODEL_PATH.exists():
        model = joblib.load(MODEL_PATH)


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": model is not None}


@app.post("/v1/predict", response_model=PredictionResponse)
def predict(request: PredictionRequest):
    if model is None:
        raise HTTPException(status_code=503, detail="Model is not loaded")

    row = pd.DataFrame([{
        "age": request.age,
        "income": request.income,
        "transactions": request.transactions,
        "credit_score": request.credit_score,
    }])
    prediction = int(model.predict(row)[0])
    probability = float(model.predict_proba(row)[0][1])
    return PredictionResponse(prediction=prediction, probability=probability)
