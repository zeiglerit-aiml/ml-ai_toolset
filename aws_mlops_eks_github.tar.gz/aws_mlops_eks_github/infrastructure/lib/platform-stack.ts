import * as cdk from "aws-cdk-lib";
import * as ec2 from "aws-cdk-lib/aws-ec2";
import * as eks from "aws-cdk-lib/aws-eks";
import * as ecr from "aws-cdk-lib/aws-ecr";
import * as s3 from "aws-cdk-lib/aws-s3";
import { Construct } from "constructs";

export class PlatformStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const vpc = new ec2.Vpc(this, "Vpc", { maxAzs: 3, natGateways: 1 });

    const cluster = new eks.Cluster(this, "Eks", {
      clusterName: "ml-platform",
      vpc,
      version: eks.KubernetesVersion.V1_33,
      defaultCapacity: 0
    });

    cluster.addNodegroupCapacity("CpuNodes", {
      minSize: 2,
      desiredSize: 2,
      maxSize: 8,
      instanceTypes: [new ec2.InstanceType("m7i.large")]
    });

    new ecr.Repository(this, "InferenceRepo", { repositoryName: "ml-inference" });
    new ecr.Repository(this, "PipelineRepo", { repositoryName: "ml-pipeline" });

    new s3.Bucket(this, "ModelBucket", {
      versioned: true,
      encryption: s3.BucketEncryption.S3_MANAGED,
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL
    });
  }
}
