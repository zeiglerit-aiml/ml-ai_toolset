# AWS Python MLOps Platform — GitHub Actions + EKS

A Python-first ML platform that ingests structured and document data, trains and evaluates models, publishes model artifacts to S3, containerizes inference, and serves the model from persistent Amazon EKS. AWS infrastructure is defined with CDK in TypeScript; GitHub Actions provides CI/CD.

## Architecture

```text
CSV / JSON / TXT / DOCX / PDF / JPEG / handwritten scans
                         |
                 Python ingestion/OCR
                  (Textract when needed)
                         |
                   canonical records
                         |
                feature engineering
                         |
                      train
                         |
                     evaluate
                         |
                   F1 quality gate
                         |
                model.joblib -> S3
                         |
             GitHub Actions builds image
                         |
                    ECR -> EKS
                         |
              FastAPI /v1/predict
                         |
                 agentic hub/client
```

## Repository layout

- `pipeline/` — standalone Python ML pipeline.
- `apps/inference/` — FastAPI prediction endpoint and Docker image.
- `.github/workflows/` — test, pipeline, build and EKS deployment workflows.
- `infrastructure/` — AWS CDK TypeScript for VPC, EKS, ECR and S3.
- `kubernetes/` — Kubernetes deployment/service and optional pipeline Job.
- `ansible/` — optional host/bootstrap configuration; not the EKS control plane.

## 1. Deploy the persistent AWS infrastructure

```bash
cd infrastructure
npm install
npx cdk bootstrap
npx cdk deploy --all
```

Record the generated S3 model bucket name. The stack creates the `ml-platform` EKS cluster and the `ml-inference` and `ml-pipeline` ECR repositories.

## 2. Configure GitHub Actions

Create GitHub repository secrets:

- `AWS_ROLE_ARN` — IAM role assumable by GitHub Actions through OIDC.
- `MODEL_BUCKET` — the model-artifact S3 bucket.

The AWS role needs only the permissions required for ECR pushes, EKS deployment, model S3 access, and any Textract calls used by the pipeline.

## 3. Run the Python pipeline locally

The training CSV needs these columns:

```text
age,income,transactions,credit_score,label
```

Then:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export MODEL_BUCKET=your-model-bucket
python -m pipeline.pipeline --source data/training.csv
```

The pipeline trains, evaluates, enforces `MINIMUM_F1`, and uploads `model.joblib` plus `metrics.json` to S3.

## 4. Run it through GitHub Actions

Open **Actions -> Run ML Pipeline -> Run workflow**, enter the training-source path, and run it. `.github/workflows/ml-pipeline.yml` executes the same Python command used locally.

A push to `main` that changes application/pipeline/deployment files triggers `build-deploy.yml`, which builds the inference and pipeline images, pushes them to ECR, configures `kubectl`, and rolls the inference deployment on EKS.

## 5. Use the inference endpoint

The API exposes:

```text
GET  /health
POST /v1/predict
```

For local testing, first ensure `/models/model.joblib` exists or provide `MODEL_BUCKET` and `MODEL_KEY`, then run:

```bash
uvicorn apps.inference.app.main:app --host 0.0.0.0 --port 8000
```

Query it with curl:

```bash
curl -X POST http://localhost:8000/v1/predict \
  -H 'Content-Type: application/json' \
  -d '{
    "age": 52,
    "income": 93000,
    "transactions": 31,
    "credit_score": 732
  }'
```

Example response:

```json
{
  "prediction": 0,
  "probability": 0.183,
  "model": "document-risk-classifier"
}
```

### Query the service inside EKS

```bash
kubectl port-forward service/ml-inference 8080:80
curl -X POST http://localhost:8080/v1/predict \
  -H 'Content-Type: application/json' \
  -d '{"age":52,"income":93000,"transactions":31,"credit_score":732}'
```

### Python client

```python
import requests

payload = {
    "age": 52,
    "income": 93000,
    "transactions": 31,
    "credit_score": 732,
}

response = requests.post(
    "http://localhost:8080/v1/predict",
    json=payload,
    timeout=10,
)
response.raise_for_status()
print(response.json())
```

For a production public endpoint, put an ALB/Ingress or API gateway in front of the ClusterIP service; keep `/v1/predict` unchanged so clients and the agentic hub do not depend on the exposure mechanism.

## 6. OCR/document path

`pipeline/ingestion/router.py` uses native readers for CSV/JSON/TXT/DOCX and text-native PDFs. JPEG/PNG and image-only PDFs fall back to Amazon Textract. For production multipage PDFs, switch the demo synchronous path to Textract's S3-backed asynchronous document APIs.

## CI/CD lifecycle

```text
PR/push
  -> CI: install, Ruff, pytest
  -> build inference + pipeline containers
  -> push immutable SHA-tagged images to ECR
  -> update EKS inference Deployment
  -> rollout health check

manual/data-triggered training
  -> GitHub Actions
  -> python -m pipeline.pipeline
  -> train/evaluate/quality gate
  -> publish model to S3
  -> restart/roll model-serving deployment when promotion policy requires it
```
