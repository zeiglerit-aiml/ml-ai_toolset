from __future__ import annotations

import pandas as pd
from sklearn.model_selection import train_test_split


FEATURES = ["age", "income", "transactions", "credit_score"]
LABEL = "label"


def build_features(df: pd.DataFrame):
    missing = set(FEATURES + [LABEL]) - set(df.columns)
    if missing:
        raise ValueError(f"Training data missing columns: {sorted(missing)}")

    X = df[FEATURES].astype(float)
    y = df[LABEL].astype(int)
    return train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
