from __future__ import annotations

import json
from pathlib import Path

import boto3
import joblib


def register_model(model, metrics: dict, bucket: str, model_key: str, metrics_key: str) -> str:
    """Package locally, then publish the model and metrics to the S3 model store."""
    s3 = boto3.client("s3")
    artifact = Path("/tmp/model.joblib")
    joblib.dump(model, artifact)

    s3.upload_file(str(artifact), bucket, model_key)
    s3.put_object(
        Bucket=bucket,
        Key=metrics_key,
        Body=json.dumps(metrics, indent=2).encode(),
        ContentType="application/json",
    )
    return f"s3://{bucket}/{model_key}"
