from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


class CanonicalRecord(BaseModel):
    source_uri: str
    source_type: str
    text: str = ""
    fields: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
