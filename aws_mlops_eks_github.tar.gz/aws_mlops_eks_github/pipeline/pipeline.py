from __future__ import annotations

import argparse
import json
import os

import pandas as pd

from pipeline.evaluation.evaluate import evaluate
from pipeline.features.build import build_features
from pipeline.registry.register import register_model
from pipeline.training.train import train


def run_pipeline(source: str) -> dict:
    print("[1/5] Loading structured training data")
    df = pd.read_csv(source) if source.endswith(".csv") else pd.read_parquet(source)

    print("[2/5] Building train/test features")
    X_train, X_test, y_train, y_test = build_features(df)

    print("[3/5] Training")
    model = train(X_train, y_train)

    print("[4/5] Evaluating")
    metrics = evaluate(model, X_test, y_test)
    print(json.dumps(metrics, indent=2))

    threshold = float(os.getenv("MINIMUM_F1", "0.80"))
    if metrics["f1"] < threshold:
        raise RuntimeError(f"F1 {metrics['f1']:.3f} is below required {threshold:.3f}")

    print("[5/5] Publishing model artifact")
    uri = register_model(
        model=model,
        metrics=metrics,
        bucket=os.environ["MODEL_BUCKET"],
        model_key=os.getenv("MODEL_KEY", "models/document-risk-classifier/model.joblib"),
        metrics_key=os.getenv("METRICS_KEY", "models/document-risk-classifier/metrics.json"),
    )
    return {"model_uri": uri, "metrics": metrics}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, help="CSV or Parquet training dataset")
    args = parser.parse_args()
    run_pipeline(args.source)
