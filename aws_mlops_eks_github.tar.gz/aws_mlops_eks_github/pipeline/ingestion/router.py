from __future__ import annotations

import io
from pathlib import Path

import boto3
import pandas as pd
from docx import Document
from pypdf import PdfReader


class IngestionRouter:
    """Turn supported source files into a DataFrame or extracted text."""

    def __init__(self, region: str = "us-east-1") -> None:
        self.textract = boto3.client("textract", region_name=region)

    def ingest(self, source: str):
        suffix = Path(source).suffix.lower()
        if suffix == ".csv":
            return pd.read_csv(source)
        if suffix == ".json":
            return pd.read_json(source)
        if suffix == ".txt":
            return Path(source).read_text(encoding="utf-8")
        if suffix == ".docx":
            return self._read_docx(source)
        if suffix == ".pdf":
            return self._read_pdf(source)
        if suffix in {".jpg", ".jpeg", ".png"}:
            return self._ocr_image(source)
        raise ValueError(f"Unsupported input type: {suffix}")

    @staticmethod
    def _read_docx(source: str) -> str:
        doc = Document(source)
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())

    def _read_pdf(self, source: str) -> str:
        reader = PdfReader(source)
        text = "\n".join((page.extract_text() or "") for page in reader.pages).strip()
        # Text-native PDF: don't OCR it unnecessarily.
        if len(text) >= 50:
            return text
        # Demo path for a local single-page scan. Production multipage PDFs should
        # be uploaded to S3 and processed with Textract async APIs.
        return self._ocr_image(source)

    def _ocr_image(self, source: str) -> str:
        payload = Path(source).read_bytes()
        response = self.textract.detect_document_text(Document={"Bytes": payload})
        return "\n".join(
            block["Text"]
            for block in response.get("Blocks", [])
            if block.get("BlockType") == "LINE"
        )
