import os
from pathlib import Path


PROVIDER = os.getenv("STORAGE_PROVIDER", "local").lower()
BUCKET = os.getenv("ARTIFACT_BUCKET", "python-ai-lab")
LOCAL_ROOT = Path(os.getenv("LOCAL_ARTIFACT_ROOT", "./artifacts"))


class ObjectStore:
    def upload(self, local_path: str | Path, key: str) -> str:
        local_path = Path(local_path)

        if PROVIDER == "local":
            destination = LOCAL_ROOT / key
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(local_path.read_bytes())
            return str(destination)

        if PROVIDER == "aws":
            import boto3
            boto3.client("s3").upload_file(str(local_path), BUCKET, key)
            return f"s3://{BUCKET}/{key}"

        if PROVIDER == "azure":
            from azure.storage.blob import BlobServiceClient
            connection = os.environ["AZURE_STORAGE_CONNECTION_STRING"]
            service = BlobServiceClient.from_connection_string(connection)
            container = service.get_container_client(BUCKET)
            try:
                container.create_container()
            except Exception:
                pass
            with open(local_path, "rb") as handle:
                container.upload_blob(name=key, data=handle, overwrite=True)
            return f"azure://{BUCKET}/{key}"

        if PROVIDER == "gcp":
            from google.cloud import storage
            client = storage.Client()
            bucket = client.bucket(BUCKET)
            blob = bucket.blob(key)
            blob.upload_from_filename(str(local_path))
            return f"gs://{BUCKET}/{key}"

        raise ValueError(f"Unsupported STORAGE_PROVIDER: {PROVIDER}")


store = ObjectStore()
