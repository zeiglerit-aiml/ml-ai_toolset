import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  template: `
    <main>
      <header>
        <span class="brand">PYTHON AI LAB</span>
        <span class="sub">Kubernetes microservice workbench</span>
      </header>

      <section class="hero">
        <p class="eyebrow">SINGLE PANE OF GLASS</p>
        <h1>Five very different things Python does brilliantly.</h1>
        <p class="lead">
          Select a microservice. Each card maps to an independently
          containerized FastAPI workload.
        </p>
      </section>

      <section class="grid">
        <a class="card" *ngFor="let item of services" [href]="item.href">
          <span class="number">{{ item.number }}</span>
          <h2>{{ item.title }}</h2>
          <p>{{ item.description }}</p>
          <small>{{ item.stack }}</small>
        </a>
      </section>
    </main>
  `,
  styles: [`
    :host {
      font-family: Inter, ui-sans-serif, system-ui, sans-serif;
      color: #f8fafc;
    }

    main {
      min-height: 100vh;
      padding: 0 max(24px, 5vw) 80px;
      background:
        radial-gradient(circle at 15% 5%, rgba(124,58,237,.28), transparent 30rem),
        #080d19;
    }

    header {
      min-height: 76px;
      border-bottom: 1px solid rgba(255,255,255,.1);
      display:flex;
      align-items:center;
      justify-content:space-between;
    }

    .brand { font-weight:800; letter-spacing:.14em; }
    .sub { color:#94a3b8; }

    .hero { max-width:900px; padding:90px 0 56px; }

    .eyebrow {
      color:#a78bfa;
      letter-spacing:.18em;
      font-size:.78rem;
      font-weight:800;
    }

    h1 {
      font-size:clamp(3.2rem,7vw,6.8rem);
      line-height:.92;
      letter-spacing:-.06em;
      margin:14px 0 26px;
    }

    .lead {
      max-width:700px;
      color:#a8b1c7;
      font-size:1.2rem;
    }

    .grid {
      display:grid;
      grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
      gap:18px;
    }

    .card {
      min-height:250px;
      padding:26px;
      border-radius:22px;
      border:1px solid rgba(255,255,255,.10);
      background:rgba(255,255,255,.045);
      color:inherit;
      text-decoration:none;
      transition:transform .18s ease,border-color .18s ease;
    }

    .card:hover {
      transform:translateY(-4px);
      border-color:#8b5cf6;
    }

    .number { color:#8b5cf6; font-weight:800; }
    .card h2 { margin-top:44px; }
    .card p { color:#9aa6bc; min-height:64px; }
    .card small { color:#c4b5fd; }
  `]
})
class AppComponent {
  services = [
    {
      number: '01',
      title: 'Music Popularity ML',
      description: 'Train Random Forest and XGBoost on a public music dataset.',
      stack: 'pandas · sklearn · XGBoost',
      href: '/api/music/docs'
    },
    {
      number: '02',
      title: 'Deep Learning Lab',
      description: 'Train a PyTorch CNN using FashionMNIST.',
      stack: 'PyTorch · torchvision',
      href: '/api/deep/docs'
    },
    {
      number: '03',
      title: 'Poetry Teacher',
      description: 'Learn forms, write original poems, and critique drafts.',
      stack: 'vLLM · OpenAI · Anthropic',
      href: '/api/poetry/docs'
    },
    {
      number: '04',
      title: 'ML Math Visualizer',
      description: 'See gradient descent, activation functions, PCA and K-Means.',
      stack: 'NumPy · SciPy · Matplotlib',
      href: '/api/math/docs'
    },
    {
      number: '05',
      title: 'Scientific Python Lab',
      description: 'Explore simulations, optimization and differential equations.',
      stack: 'NumPy · SciPy · Matplotlib',
      href: '/api/science/docs'
    }
  ];
}

bootstrapApplication(AppComponent);
