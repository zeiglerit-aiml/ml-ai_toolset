from io import BytesIO

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from scipy.integrate import solve_ivp
from scipy.optimize import minimize


app = FastAPI(title="Scientific Python Lab")


class MonteCarloRequest(BaseModel):
    samples: int = Field(default=100000, ge=1000, le=2_000_000)


class ProjectileRequest(BaseModel):
    speed_mps: float = Field(default=30, gt=0)
    angle_degrees: float = Field(default=45, gt=0, lt=90)


def png_response():
    buffer = BytesIO()
    plt.tight_layout()
    plt.savefig(buffer, format="png")
    plt.close()
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="image/png")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/monte-carlo/pi")
def monte_carlo_pi(request: MonteCarloRequest):
    rng = np.random.default_rng()
    x = rng.random(request.samples)
    y = rng.random(request.samples)
    inside = x * x + y * y <= 1

    estimate = 4 * inside.mean()

    return {
        "samples": request.samples,
        "estimate": float(estimate),
        "numpy_pi": float(np.pi),
        "absolute_error": float(abs(estimate - np.pi)),
    }


@app.get("/optimize")
def optimize():
    def objective(x):
        return (x[0] - 4) ** 2 + (x[1] + 2) ** 2

    result = minimize(objective, [0, 0])

    return {
        "x": float(result.x[0]),
        "y": float(result.x[1]),
        "objective": float(result.fun),
        "success": bool(result.success),
    }


@app.post("/projectile")
def projectile(request: ProjectileRequest):
    g = 9.81
    theta = np.deg2rad(request.angle_degrees)

    vx = request.speed_mps * np.cos(theta)
    vy = request.speed_mps * np.sin(theta)

    total_time = 2 * vy / g
    t = np.linspace(0, total_time, 200)

    x = vx * t
    y = vy * t - 0.5 * g * t**2

    plt.figure(figsize=(8, 5))
    plt.plot(x, y)
    plt.title("Projectile Motion")
    plt.xlabel("Horizontal distance (m)")
    plt.ylabel("Height (m)")

    return png_response()


@app.get("/damped-oscillator")
def damped_oscillator():
    def system(t, state):
        x, v = state
        damping = 0.35
        spring = 2.0
        return [v, -damping * v - spring * x]

    result = solve_ivp(
        system,
        (0, 20),
        [1.0, 0.0],
        dense_output=True,
    )

    t = np.linspace(0, 20, 500)
    x = result.sol(t)[0]

    plt.figure(figsize=(8, 5))
    plt.plot(t, x)
    plt.title("Damped Harmonic Oscillator")
    plt.xlabel("Time")
    plt.ylabel("Displacement")

    return png_response()
