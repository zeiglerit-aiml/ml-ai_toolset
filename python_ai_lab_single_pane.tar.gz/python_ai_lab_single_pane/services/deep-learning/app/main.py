from pathlib import Path
import sys

import numpy as np
import torch
import torch.nn as nn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms

sys.path.append("/common")
from storage import store  # noqa: E402


app = FastAPI(title="Fashion Deep Learning Lab")

ARTIFACTS = Path("/app/artifacts")
ARTIFACTS.mkdir(exist_ok=True)
MODEL_PATH = ARTIFACTS / "fashion_cnn.pt"

LABELS = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot",
]


class FashionCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(1, 12, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(12, 24, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Flatten(),
            nn.Linear(24 * 7 * 7, 64),
            nn.ReLU(),
            nn.Linear(64, 10),
        )

    def forward(self, x):
        return self.net(x)


DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
MODEL = FashionCNN().to(DEVICE)

if MODEL_PATH.exists():
    MODEL.load_state_dict(torch.load(MODEL_PATH, map_location=DEVICE))


class ImageRequest(BaseModel):
    pixels: list[float] = Field(
        description="784 grayscale values in [0,1], flattened 28x28 image."
    )


@app.get("/health")
def health():
    return {
        "status": "ok",
        "device": str(DEVICE),
        "artifact_exists": MODEL_PATH.exists(),
    }


@app.post("/train")
def train(
    epochs: int = 1,
    max_samples: int = 12000,
):
    transform = transforms.ToTensor()

    dataset = datasets.FashionMNIST(
        root="/app/data",
        train=True,
        download=True,
        transform=transform,
    )

    subset = Subset(
        dataset,
        range(min(max_samples, len(dataset))),
    )

    loader = DataLoader(
        subset,
        batch_size=128,
        shuffle=True,
    )

    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        MODEL.parameters(),
        lr=0.001,
    )

    MODEL.train()

    for _ in range(epochs):
        for images, labels in loader:
            images = images.to(DEVICE)
            labels = labels.to(DEVICE)

            optimizer.zero_grad()
            logits = MODEL(images)
            loss = loss_fn(logits, labels)
            loss.backward()
            optimizer.step()

    torch.save(MODEL.state_dict(), MODEL_PATH)

    uri = store.upload(
        MODEL_PATH,
        "models/fashion/fashion_cnn.pt",
    )

    return {
        "status": "trained",
        "epochs": epochs,
        "samples": len(subset),
        "artifact_uri": uri,
        "device": str(DEVICE),
    }


@app.post("/predict")
def predict(request: ImageRequest):
    if len(request.pixels) != 784:
        raise HTTPException(
            status_code=422,
            detail="pixels must contain exactly 784 values.",
        )

    array = np.array(request.pixels, dtype=np.float32)
    tensor = torch.tensor(
        array.reshape(1, 1, 28, 28),
        dtype=torch.float32,
        device=DEVICE,
    )

    MODEL.eval()

    with torch.no_grad():
        probabilities = torch.softmax(MODEL(tensor), dim=1)[0]

    index = int(torch.argmax(probabilities).item())

    return {
        "class_id": index,
        "label": LABELS[index],
        "confidence_percent": round(
            float(probabilities[index].item()) * 100,
            2,
        ),
    }
