from io import BytesIO

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA


app = FastAPI(title="ML Math Visualizer")


class GradientRequest(BaseModel):
    learning_rate: float = Field(default=0.1, gt=0, le=1)
    iterations: int = Field(default=20, ge=2, le=100)
    starting_point: float = -4.0


def png_response():
    buffer = BytesIO()
    plt.tight_layout()
    plt.savefig(buffer, format="png")
    plt.close()
    buffer.seek(0)
    return StreamingResponse(buffer, media_type="image/png")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/gradient-descent")
def gradient_descent(request: GradientRequest):
    def loss(x):
        return (x - 3) ** 2

    def gradient(x):
        return 2 * (x - 3)

    x = request.starting_point
    history = []

    for _ in range(request.iterations):
        history.append((x, loss(x)))
        x -= request.learning_rate * gradient(x)

    curve_x = np.linspace(-5, 8, 300)
    curve_y = loss(curve_x)

    plt.figure(figsize=(8, 5))
    plt.plot(curve_x, curve_y, label="Loss function")
    plt.scatter(
        [x[0] for x in history],
        [x[1] for x in history],
        label="Gradient steps",
    )
    plt.title("Gradient Descent on (x - 3)^2")
    plt.legend()

    return png_response()


@app.get("/activations")
def activations():
    x = np.linspace(-6, 6, 400)
    sigmoid = 1 / (1 + np.exp(-x))
    relu = np.maximum(0, x)
    tanh = np.tanh(x)

    plt.figure(figsize=(8, 5))
    plt.plot(x, sigmoid, label="Sigmoid")
    plt.plot(x, relu, label="ReLU")
    plt.plot(x, tanh, label="tanh")
    plt.title("Common Neural Network Activations")
    plt.legend()

    return png_response()


@app.get("/kmeans")
def kmeans():
    rng = np.random.default_rng(42)

    X = np.vstack([
        rng.normal([0, 0], 0.7, size=(80, 2)),
        rng.normal([4, 4], 0.7, size=(80, 2)),
        rng.normal([0, 5], 0.7, size=(80, 2)),
    ])

    model = KMeans(n_clusters=3, random_state=42, n_init="auto")
    labels = model.fit_predict(X)

    plt.figure(figsize=(7, 6))
    plt.scatter(X[:, 0], X[:, 1], c=labels)
    plt.scatter(
        model.cluster_centers_[:, 0],
        model.cluster_centers_[:, 1],
        marker="x",
        s=160,
    )
    plt.title("K-Means Clustering")

    return png_response()


@app.get("/pca")
def pca():
    rng = np.random.default_rng(42)
    X = rng.normal(size=(300, 4))
    X[:, 1] = X[:, 0] * 0.8 + rng.normal(scale=0.3, size=300)

    projected = PCA(n_components=2).fit_transform(X)

    plt.figure(figsize=(7, 6))
    plt.scatter(projected[:, 0], projected[:, 1], s=16)
    plt.title("PCA: 4 Dimensions → 2 Dimensions")

    return png_response()
