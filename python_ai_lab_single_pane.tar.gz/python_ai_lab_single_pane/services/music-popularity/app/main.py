from pathlib import Path
import sys

import joblib
import numpy as np
import pandas as pd
from datasets import load_dataset
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor

sys.path.append("/common")
from storage import store  # noqa: E402


app = FastAPI(title="Music Popularity ML")

ARTIFACTS = Path("/app/artifacts")
ARTIFACTS.mkdir(exist_ok=True)

MODEL_PATH = ARTIFACTS / "music_model.joblib"
FEATURES = [
    "danceability",
    "energy",
    "loudness",
    "speechiness",
    "acousticness",
    "instrumentalness",
    "liveness",
    "valence",
    "tempo",
    "duration_ms",
]

MODEL = joblib.load(MODEL_PATH) if MODEL_PATH.exists() else None
MODEL_NAME = "untrained"
METRICS = {}


class SongFeatures(BaseModel):
    danceability: float = Field(ge=0, le=1)
    energy: float = Field(ge=0, le=1)
    loudness: float
    speechiness: float = Field(ge=0, le=1)
    acousticness: float = Field(ge=0, le=1)
    instrumentalness: float = Field(ge=0, le=1)
    liveness: float = Field(ge=0, le=1)
    valence: float = Field(ge=0, le=1)
    tempo: float = Field(gt=0)
    duration_ms: float = Field(gt=0)


def load_training_frame(limit: int = 30000) -> pd.DataFrame:
    dataset = load_dataset(
        "maharshipandya/spotify-tracks-dataset",
        split="train",
    )

    frame = dataset.to_pandas()

    needed = FEATURES + ["popularity"]
    frame = frame[needed].dropna()

    if len(frame) > limit:
        frame = frame.sample(limit, random_state=42)

    return frame


@app.get("/health")
def health():
    return {
        "status": "ok",
        "model": MODEL_NAME,
        "trained": MODEL is not None,
        "metrics": METRICS,
    }


@app.post("/train")
def train(limit: int = 30000):
    global MODEL, MODEL_NAME, METRICS

    df = load_training_frame(limit)

    X_train, X_test, y_train, y_test = train_test_split(
        df[FEATURES],
        df["popularity"],
        test_size=0.2,
        random_state=42,
    )

    candidates = {
        "random_forest": RandomForestRegressor(
            n_estimators=160,
            random_state=42,
            n_jobs=-1,
        ),
        "xgboost": XGBRegressor(
            n_estimators=220,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.85,
            colsample_bytree=0.85,
            random_state=42,
        ),
    }

    results = {}

    for name, model in candidates.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test)

        results[name] = {
            "mae": float(mean_absolute_error(y_test, pred)),
            "r2": float(r2_score(y_test, pred)),
        }

    MODEL_NAME = min(results, key=lambda name: results[name]["mae"])
    MODEL = candidates[MODEL_NAME]
    METRICS = results[MODEL_NAME]

    joblib.dump(
        {
            "name": MODEL_NAME,
            "model": MODEL,
            "features": FEATURES,
            "metrics": METRICS,
        },
        MODEL_PATH,
    )

    model_uri = store.upload(
        MODEL_PATH,
        "models/music/music_model.joblib",
    )

    sample_path = ARTIFACTS / "music_training_sample.parquet"
    df.head(5000).to_parquet(sample_path, index=False)

    data_uri = store.upload(
        sample_path,
        "datasets/music/music_training_sample.parquet",
    )

    return {
        "winner": MODEL_NAME,
        "metrics": results,
        "model_uri": model_uri,
        "sample_data_uri": data_uri,
        "rows_used": len(df),
    }


@app.post("/predict")
def predict(song: SongFeatures):
    if MODEL is None:
        raise HTTPException(
            status_code=409,
            detail="Model is not trained. POST /train first.",
        )

    row = pd.DataFrame([song.model_dump()])[FEATURES]
    value = float(MODEL.predict(row)[0])
    value = float(np.clip(value, 0, 100))

    return {
        "predicted_popularity": round(value, 1),
        "popularity_band": (
            "HIGH" if value >= 70
            else "MEDIUM" if value >= 40
            else "LOW"
        ),
        "model": MODEL_NAME,
    }
