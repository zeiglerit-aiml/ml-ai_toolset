import os
from fastapi import FastAPI
from pydantic import BaseModel, Field


app = FastAPI(title="Poetry Teacher AI")


class PoetryRequest(BaseModel):
    topic: str
    style: str = Field(
        default="haiku",
        description="haiku, sonnet, limerick, free_verse, ode",
    )
    level: str = Field(
        default="beginner",
        description="beginner, intermediate, advanced",
    )


class CritiqueRequest(BaseModel):
    poem: str
    style: str = "free_verse"


def system_prompt() -> str:
    return (
        "You are a friendly poetry teacher. "
        "Teach form, imagery, meter, sound, metaphor, revision, and close reading. "
        "When asked to write a poem, produce an original poem and then briefly explain "
        "the choices made. Never claim a generated poem is by a real poet."
    )


def build_prompt(request: PoetryRequest) -> str:
    return (
        f"Teach a {request.level} student how to write a {request.style} "
        f"about: {request.topic}. Give a concise lesson, an original example poem, "
        "and two exercises."
    )


def call_llm(prompt: str) -> str:
    provider = os.getenv("LLM_PROVIDER", "vllm").lower()

    if provider in {"vllm", "openai"}:
        from openai import OpenAI

        if provider == "vllm":
            client = OpenAI(
                base_url=os.getenv("VLLM_BASE_URL", "http://vllm:8000/v1"),
                api_key=os.getenv("VLLM_API_KEY", "unused"),
            )
            model = os.getenv("VLLM_MODEL", "YOUR_MODEL")
        else:
            client = OpenAI()
            model = os.getenv("OPENAI_MODEL", "YOUR_OPENAI_MODEL")

        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt()},
                {"role": "user", "content": prompt},
            ],
        )
        return response.choices[0].message.content or ""

    if provider == "anthropic":
        import anthropic

        client = anthropic.Anthropic()
        response = client.messages.create(
            model=os.getenv("ANTHROPIC_MODEL", "YOUR_CLAUDE_MODEL"),
            max_tokens=900,
            system=system_prompt(),
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(
            block.text
            for block in response.content
            if hasattr(block, "text")
        )

    raise ValueError(f"Unsupported LLM_PROVIDER: {provider}")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "provider": os.getenv("LLM_PROVIDER", "vllm"),
    }


@app.post("/teach")
def teach(request: PoetryRequest):
    return {
        "style": request.style,
        "lesson": call_llm(build_prompt(request)),
    }


@app.post("/critique")
def critique(request: CritiqueRequest):
    prompt = (
        f"Critique this {request.style} poem as a poetry teacher. "
        "Discuss imagery, sound, form, strongest line-level choices, and three revisions.\n\n"
        f"{request.poem}"
    )
    return {"critique": call_llm(prompt)}
