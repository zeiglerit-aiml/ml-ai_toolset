import os
import httpx
from fastapi import FastAPI, Request
from fastapi.responses import Response


app = FastAPI(title="Python AI Lab Gateway")

SERVICES = {
    "music": os.getenv("MUSIC_URL", "http://music-popularity:8000"),
    "deep": os.getenv("DEEP_URL", "http://deep-learning:8000"),
    "poetry": os.getenv("POETRY_URL", "http://poetry-teacher:8000"),
    "math": os.getenv("MATH_URL", "http://math-visualizer:8000"),
    "science": os.getenv("SCIENCE_URL", "http://science-lab:8000"),
}


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "services": SERVICES,
    }


@app.api_route(
    "/api/{service}/{path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
)
async def proxy(service: str, path: str, request: Request):
    target = SERVICES[service]

    async with httpx.AsyncClient(timeout=180) as client:
        response = await client.request(
            request.method,
            f"{target}/{path}",
            content=await request.body(),
            params=request.query_params,
            headers={
                "content-type": request.headers.get(
                    "content-type",
                    "application/json",
                )
            },
        )

    return Response(
        content=response.content,
        status_code=response.status_code,
        media_type=response.headers.get("content-type"),
    )
