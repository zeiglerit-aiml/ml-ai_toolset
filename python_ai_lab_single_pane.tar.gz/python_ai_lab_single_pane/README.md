# Python AI Lab — Single Pane of Glass

A Kubernetes-ready proof-of-concept made of five independent Python microservices plus one Angular frontend and one FastAPI gateway.

## Services

1. **Music Popularity ML**
   - pandas
   - NumPy
   - scikit-learn
   - XGBoost
   - Matplotlib
   - public Spotify-derived dataset from Hugging Face
   - trains models and exposes FastAPI inference

2. **Deep Learning Lab**
   - PyTorch
   - torchvision
   - FashionMNIST public dataset
   - CNN training
   - model artifact export
   - FastAPI

3. **Poetry Teacher AI**
   - FastAPI
   - vLLM / OpenAI-compatible provider
   - OpenAI provider
   - Anthropic provider
   - teaches haiku, sonnet, free verse, limerick, and critique

4. **ML Math Visualizer**
   - NumPy
   - SciPy
   - scikit-learn
   - Matplotlib
   - visualizes gradient descent, activation functions, K-Means and PCA

5. **Scientific Python Lab**
   - NumPy
   - SciPy
   - Matplotlib
   - numerical optimization
   - Monte Carlo
   - projectile motion
   - differential equations

## Application shape

```text
Angular
   |
   v
FastAPI Gateway
   |
   +--> Music Popularity ML
   +--> Deep Learning Lab
   +--> Poetry Teacher AI
   +--> ML Math Visualizer
   +--> Scientific Python Lab
```

Each backend is independently containerized and independently deployable.

## Kubernetes / GitOps shape

```text
GitHub Actions
    |
    +--> test/build container images
    +--> push registry
    +--> update image tags/values
              |
              v
           Argo CD
              |
              v
            Helm
              |
              v
       EKS / AKS / GKE
```

This repo does **not** create the cloud infrastructure. Your separate platform IaC should already provide:

- Kubernetes cluster
- container registry
- object storage
- IAM/workload identity
- DNS/Gateway foundation
- optional Vault / OPA / observability

## Data philosophy

The repo does not ship giant proprietary training datasets.

Training demos use reproducible public data:

- Music service: public Spotify-derived tabular dataset loaded through Hugging Face `datasets`
- Deep-learning service: FashionMNIST downloaded by `torchvision`

The other three services do not require trained datasets.

## Quick local start

Docker Compose:

```bash
docker compose up --build
```

Then:

- Angular: `http://localhost:4200`
- Gateway: `http://localhost:8080/docs`
- Music: `http://localhost:8001/docs`
- Deep Learning: `http://localhost:8002/docs`
- Poetry: `http://localhost:8003/docs`
- Math: `http://localhost:8004/docs`
- Science: `http://localhost:8005/docs`

## Helm

Standalone chart install:

```bash
helm upgrade --install music \
  ./helm/music-popularity \
  --namespace python-ai-lab \
  --create-namespace \
  --set image.repository=YOUR_REGISTRY/music-popularity \
  --set image.tag=1.0
```

Whole application:

```bash
helm dependency update helm/python-ai-lab

helm upgrade --install python-ai-lab \
  ./helm/python-ai-lab \
  --namespace python-ai-lab \
  --create-namespace \
  -f helm/python-ai-lab/values-demo.yaml
```

## Argo CD

Edit:

```text
argocd/python-ai-lab.application.yaml
```

and replace the repository URL and image repositories.

## Object storage

The ML services support a common object-storage helper.

Environment:

```text
STORAGE_PROVIDER=local|aws|azure|gcp
ARTIFACT_BUCKET=<bucket/container>
```

For lightweight local development the default is `local`.

Cloud platform mapping:

```text
AWS   -> S3
Azure -> Blob Storage
GCP   -> GCS
```

The training containers can write processed data, metrics, and model artifacts to the storage provisioned by your infrastructure stack.

## Repo layout

```text
python_ai_lab_single_pane/
├── frontend-angular/
├── gateway/
├── services/
│   ├── music-popularity/
│   ├── deep-learning/
│   ├── poetry-teacher/
│   ├── math-visualizer/
│   └── science-lab/
├── common/
├── helm/
├── argocd/
├── docker-compose.yml
└── .github/workflows/
```
