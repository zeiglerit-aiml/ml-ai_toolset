# Auto-discovery

Any Kubernetes Service can opt into the generic Prometheus ServiceMonitor by exposing a named port `metrics` and applying this label:

```yaml
metadata:
  labels:
    observability.zeigler.io/prometheus: "true"
```

Example:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: model-api
  labels:
    observability.zeigler.io/prometheus: "true"
spec:
  selector:
    app: model-api
  ports:
    - name: http
      port: 8000
      targetPort: 8000
    - name: metrics
      port: 8001
      targetPort: 8001
```

For applications that serve `/metrics` on the same HTTP port, name that Service port `metrics` or add a dedicated Service for scraping.
