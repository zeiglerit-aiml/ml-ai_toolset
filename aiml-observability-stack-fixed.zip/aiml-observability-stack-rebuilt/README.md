# AI/ML Observability Stack

An opinionated, out-of-the-box Kubernetes observability platform geared toward **AI/ML model serving, LLM serving, agents, and training/data pipelines** without being limited to any one framework.

The stack gives you one operational plane for:

- Kubernetes, nodes, pods, containers, CPU, memory and networking
- NVIDIA GPU/DCGM telemetry
- FastAPI and arbitrary Python services
- vLLM / LLM serving metrics
- LangGraph / LangChain / MCP agent traces and tool latency
- MLflow model serving and training jobs
- TensorFlow, PyTorch, scikit-learn, XGBoost and custom model services
- Kafka consumer lag / event-driven workflows
- PostgreSQL / pgvector health and query performance
- Redis state/cache services
- object-storage and Parquet/Iceberg-oriented pipeline stages via application metrics/traces
- distributed traces, logs, metrics, model/agent quality signals, token/cost telemetry

## Architecture

```text
AI/ML workloads
  FastAPI | vLLM | MLflow | LangGraph | MCP | TensorFlow | PyTorch
  Kafka | PostgreSQL/pgvector | Redis | pipeline jobs
                         |
                    OpenTelemetry
                         |
              +----------+----------+
              |                     |
         OTEL Collector         Prometheus
              |                     |
       +------+------+              |
       |             |              |
     Tempo         Loki           Grafana
    traces         logs          dashboards
       |
    Langfuse
 AI/agent traces + evals

GPU nodes -> NVIDIA DCGM Exporter -> Prometheus
Kubernetes -> kube-state-metrics/node-exporter -> Prometheus
Alerts -> Alertmanager
```

## One-command GCP deployment

Prerequisites: `gcloud`, `terraform`, `kubectl`, and Helm 3.17+ authenticated to a GCP project.

```bash
./deploy.sh --cloud=gcp --project=my-project --region=us-central1
```

Optional sizing:

```bash
./deploy.sh --cloud=gcp \
  --project=my-project \
  --region=us-central1 \
  --cluster=aiml-observability \
  --min-nodes=2 \
  --max-nodes=5
```

Destroy:

```bash
./destroy.sh --cloud=gcp --project=my-project --region=us-central1
```

## What is installed

| Capability | Component |
|---|---|
| Metrics + alerting | Prometheus Operator / kube-prometheus-stack + Alertmanager |
| Visualization | Grafana |
| Distributed traces | Tempo |
| Logs | Loki |
| Telemetry routing | OpenTelemetry Collector |
| AI/agent observability | Langfuse |
| GPU telemetry | NVIDIA DCGM Exporter |
| K8s/node telemetry | kube-state-metrics + node-exporter |

## Default dashboards

The repo seeds an opinionated `AI-ML Overview` dashboard. The chart stack also supplies Kubernetes dashboards. Add or customize JSON dashboards under `grafana/dashboards/`.

Suggested dashboard groups:

1. Cluster & Kubernetes health
2. GPU fleet
3. LLM/vLLM serving
4. ML model serving
5. Agent/LangGraph/MCP operations
6. PostgreSQL/pgvector and Redis
7. Kafka/event workflows
8. Training & data pipelines
9. Cost/token/evaluation signals
10. SLOs and alerting

## Generic thresholds

Defaults are intentionally conservative and editable in `alerts/aiml-rules.yaml`:

- HTTP 5xx > 5% for 10m
- p95 request latency > 2s for 10m
- pod restarts > 3 in 15m
- CPU > 85% for 15m
- memory working set > 90% of limit for 10m
- GPU utilization > 95% for 15m
- GPU framebuffer memory > 90% for 10m
- vLLM waiting requests > 10 for 5m
- Kafka consumer lag > 10,000 for 10m (when exporter metrics exist)
- PostgreSQL connection saturation > 85% for 10m (when exporter metrics exist)
- agent/tool error ratio > 5% for 10m (when application metrics exist)

These are **starter thresholds**, not production truth. Tune by workload, SLO, model size, traffic pattern, hardware, and business impact.

## Instrumentation contract

The platform is intentionally source-agnostic. Workloads should expose one or both of:

1. Prometheus-compatible `/metrics`
2. OTLP telemetry to the in-cluster collector

Examples are under `examples/`.

### FastAPI

Use OpenTelemetry middleware and/or `prometheus-client`. The service can expose model-specific signals such as prediction count, latency, model version, drift score, feature quality, and business outcome metrics.

### vLLM

Point Prometheus at the vLLM metrics endpoint. Typical useful metrics include requests running/waiting, KV-cache utilization, prompt/generation token counters, latency, and TTFT-related histograms.

### LangGraph / agents / MCP

Emit OTEL spans around graph runs, nodes, LLM calls, retrieval, database calls, and MCP tool execution. Send AI-specific traces/evaluations to Langfuse.

### Data pipelines / Parquet / Iceberg

Parquet itself is a file format, so it does not emit observability. Instrument the **jobs that read/write it**. Useful signals include files processed, bytes read/written, partition count, schema failures, data-quality failures, freshness, row counts, and stage duration.

### PostgreSQL / pgvector

Deploy a postgres exporter or use OTEL DB instrumentation for query latency/errors. For pgvector, additionally emit application-level vector-search latency, candidate count, recall/quality measures, index usage, and embedding-generation latency.

## Security defaults

- Services are ClusterIP by default; no public Grafana/Langfuse exposure is created.
- Use `kubectl port-forward`, an authenticated ingress, or your organization's zero-trust gateway.
- Tempo has no built-in authentication; do not expose it directly.
- Replace demo/default secrets before production.
- Restrict telemetry payloads to avoid leaking prompts, PII, credentials, or sensitive model inputs.

## Production notes

This repo uses practical single-cluster defaults to keep the initial deployment understandable. For high-scale production, move Loki/Tempo/Langfuse state to durable cloud storage/databases, use workload identity, separate observability from workloads when appropriate, and set retention/backup policies.


## Zero-friction Kubernetes discovery

A generic `ServiceMonitor` is installed with the stack. Any Kubernetes Service exposing a named `metrics` port can opt in with:

```yaml
metadata:
  labels:
    observability.zeigler.io/prometheus: "true"
```

This lets independently deployed FastAPI model services, vLLM endpoints, exporters, agents, and pipeline services appear in Prometheus without editing the central stack. OTLP producers can instead send telemetry to the OpenTelemetry Collector on ports `4317` (gRPC) or `4318` (HTTP).

See `docs/OBSERVABILITY-CONTRACT.md` for the common telemetry contract and recommended signals for models, LLMs, agents/MCP, training pipelines, PostgreSQL/pgvector, Kafka, and Parquet/Iceberg workloads.
