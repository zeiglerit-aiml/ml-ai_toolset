# Observability source catalog

The stack does not require every data system to speak the same protocol. It normalizes telemetry through Prometheus and OpenTelemetry.

| Source | Typical integration | Useful signals |
|---|---|---|
| FastAPI | OTEL + Prometheus | RED metrics, route latency/errors |
| vLLM | Prometheus + OTEL around API | queue, KV cache, tokens, TTFT, latency |
| LangGraph/LangChain | OTEL + Langfuse | graph/node/tool/LLM/retrieval spans |
| MCP servers | OTEL + app metrics | tool latency, error rate, authorization denials |
| MLflow | app instrumentation + MLflow tracing | inference/training, model version, evaluation |
| TensorFlow/PyTorch | custom metrics + OTEL | train/eval loss, throughput, checkpoint time |
| Kafka | exporter/JMX + OTEL in apps | consumer lag, throughput, errors |
| PostgreSQL/pgvector | postgres exporter + DB spans | connections, query/vector latency, errors |
| Redis | redis exporter + spans | memory, hit rate, latency, evictions |
| Parquet/Iceberg | instrument readers/writers | bytes/files/rows, freshness, schema/data-quality |
| GCS/S3/ADLS | cloud metrics + app spans | request errors/latency/bytes |
| Kubernetes | kube-state/node-exporter | pod/node/resource health |
| NVIDIA GPU | DCGM exporter | utilization, memory, power, temperature |
