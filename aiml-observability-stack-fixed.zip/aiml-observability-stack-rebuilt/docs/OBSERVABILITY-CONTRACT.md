# AI/ML Observability Contract

This stack accepts telemetry from workloads in the same cluster, another cluster, VMs, managed model endpoints, or data-pipeline workers. Sources do not need to run inside the observability cluster.

## Preferred inputs

1. **OTLP**: traces, metrics and logs to the OpenTelemetry Collector on ports 4317/4318.
2. **Prometheus scrape**: a `/metrics` endpoint discovered by ServiceMonitor/PodMonitor or static scrape configuration.
3. **Exporter**: for systems such as PostgreSQL, Kafka, Redis, NVIDIA GPUs, JVM services, or legacy applications.
4. **Application metrics**: for file/data formats such as Parquet and Iceberg, instrument the jobs that read/write them.

## Recommended labels

Every application metric should carry stable dimensions where practical:

- `service`
- `environment`
- `team`
- `model_name`
- `model_version`
- `pipeline_name`
- `dataset_id`
- `agent_name`
- `tool_name`

Do not put high-cardinality IDs such as raw request IDs, prompts, or document contents into Prometheus labels. Put those in traces/logs instead.

## Baseline signals

### Model serving
- request rate, error rate, p50/p95/p99 latency
- prediction count and prediction failures
- model/version currently serving
- queue depth and concurrency
- model load/reload failures
- drift/quality/business outcome metrics when available

### LLM serving
- TTFT, end-to-end latency, tokens/sec
- prompt/generated tokens, active/waiting requests
- KV-cache utilization, context length distribution
- HTTP 429/5xx, aborted requests
- GPU utilization/memory/power/temperature

### Agents and MCP
- graph runs, graph duration, node duration
- LLM calls, tool calls, retrieval calls
- tool errors/retries/timeouts
- checkpoint restores and human-approval waits
- token/cost/evaluation signals
- trace IDs spanning agent -> tool -> model/database

### Training and ML pipelines
- pipeline/run status and duration
- stage duration and retries
- rows/files/bytes processed
- training loss/validation metrics
- experiment/model version and promotion result
- data freshness and data-quality failures

### PostgreSQL/pgvector
- availability, connections, locks, slow queries
- transaction/error rate
- vector-search latency, candidates/results
- embedding generation latency and index health

### Kafka
- broker health, produce/fetch latency
- consumer lag, records/sec, errors/rebalances
- dead-letter/retry counts where implemented

### Parquet/Iceberg/object storage
The file formats themselves do not emit telemetry. Instrument readers/writers/catalog operations:
- bytes and files read/written
- partition/pruning effectiveness
- snapshot/commit duration
- schema-evolution failures
- freshness, row count, quality violations

## Starter SLO posture

The alerts shipped with the repository are deliberately generic. Treat them as smoke alarms. Establish service-specific SLOs after measuring normal behavior, and route warnings vs critical alerts by business impact.
