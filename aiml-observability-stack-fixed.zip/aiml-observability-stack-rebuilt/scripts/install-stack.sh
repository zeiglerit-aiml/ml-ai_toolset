#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

kubectl create namespace observability --dry-run=client -o yaml | kubectl apply -f -
kubectl create namespace langfuse --dry-run=client -o yaml | kubectl apply -f -

helm repo add prometheus-community https://prometheus-community.github.io/helm-charts --force-update
helm repo add grafana-community https://grafana-community.github.io/helm-charts --force-update
helm repo add open-telemetry https://open-telemetry.github.io/opentelemetry-helm-charts --force-update
helm repo add gpu-helm-charts https://nvidia.github.io/dcgm-exporter/helm-charts --force-update
helm repo add langfuse https://langfuse.github.io/langfuse-k8s --force-update
helm repo update

helm upgrade --install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
  -n observability -f "$ROOT/helm/kube-prometheus-stack/values.yaml" --wait --timeout 10m

helm upgrade --install loki grafana-community/loki \
  -n observability -f "$ROOT/helm/loki/values.yaml" --wait --timeout 10m

helm upgrade --install tempo grafana-community/tempo \
  -n observability -f "$ROOT/helm/tempo/values.yaml" --wait --timeout 10m

helm upgrade --install otel open-telemetry/opentelemetry-collector \
  -n observability -f "$ROOT/helm/otel-collector/values.yaml" --wait --timeout 10m

# DCGM exporter schedules only on GPU-capable nodes when present; harmless if none match.
helm upgrade --install dcgm-exporter gpu-helm-charts/dcgm-exporter \
  -n observability -f "$ROOT/helm/dcgm-exporter/values.yaml" || true

# Langfuse v4 bundled deployment prerequisites.
helm upgrade --install cert-manager oci://quay.io/jetstack/charts/cert-manager \
  --version v1.20.2 --namespace cert-manager --create-namespace --set crds.enabled=true --wait --timeout 10m
helm upgrade --install clickhouse-operator oci://ghcr.io/clickhouse/clickhouse-operator-helm \
  --version 0.0.5 --namespace clickhouse-operator --create-namespace --wait --timeout 10m

kubectl wait --for=condition=Established crd/clickhouseclusters.clickhouse.com crd/keeperclusters.clickhouse.com --timeout=180s

if ! kubectl -n langfuse get secret langfuse-secrets >/dev/null 2>&1; then
  SALT="$(openssl rand -hex 32)"
  ENCRYPTION_KEY="$(openssl rand -hex 32)"
  NEXTAUTH_SECRET="$(openssl rand -hex 32)"
  PG_PASSWORD="$(openssl rand -hex 24)"
  REDIS_PASSWORD="$(openssl rand -hex 24)"
  CLICKHOUSE_PASSWORD="$(openssl rand -hex 24)"
  S3_SECRET="$(openssl rand -hex 24)"
  kubectl -n langfuse create secret generic langfuse-secrets \
    --from-literal=salt="$SALT" \
    --from-literal=encryptionKey="$ENCRYPTION_KEY" \
    --from-literal=nextauthSecret="$NEXTAUTH_SECRET" \
    --from-literal=postgresPassword="$PG_PASSWORD" \
    --from-literal=redisPassword="$REDIS_PASSWORD" \
    --from-literal=clickhousePassword="$CLICKHOUSE_PASSWORD" \
    --from-literal=s3SecretAccessKey="$S3_SECRET"
fi

helm upgrade --install langfuse langfuse/langfuse \
  -n langfuse -f "$ROOT/helm/langfuse/values.yaml" --wait --timeout 20m

kubectl apply -f "$ROOT/alerts/aiml-rules.yaml"
kubectl apply -f "$ROOT/k8s/monitors/generic-servicemonitor.yaml"
kubectl apply -f "$ROOT/grafana/provisioning/dashboards/aiml-dashboard-configmap.yaml"

echo "Observability stack installed."
