#!/usr/bin/env bash
set -euo pipefail
CLOUD=""; PROJECT=""; REGION="us-central1"; CLUSTER="aiml-observability"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --cloud=*) CLOUD="${1#*=}" ;;
    --project=*) PROJECT="${1#*=}" ;;
    --region=*) REGION="${1#*=}" ;;
    --cluster=*) CLUSTER="${1#*=}" ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done
[[ "$CLOUD" == "gcp" ]] || { echo "Currently implemented: --cloud=gcp" >&2; exit 2; }
[[ -n "$PROJECT" ]] || { echo "--project required" >&2; exit 2; }
export TF_VAR_project_id="$PROJECT" TF_VAR_region="$REGION" TF_VAR_cluster_name="$CLUSTER"
terraform -chdir=terraform/gcp init
terraform -chdir=terraform/gcp destroy -auto-approve
