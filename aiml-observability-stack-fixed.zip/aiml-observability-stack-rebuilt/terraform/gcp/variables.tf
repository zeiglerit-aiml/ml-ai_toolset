variable "project_id" { type = string }
variable "region" { type = string default = "us-central1" }
variable "cluster_name" { type = string default = "aiml-observability" }
variable "min_nodes" { type = number default = 2 }
variable "max_nodes" { type = number default = 5 }
variable "machine_type" { type = string default = "e2-standard-4" }
