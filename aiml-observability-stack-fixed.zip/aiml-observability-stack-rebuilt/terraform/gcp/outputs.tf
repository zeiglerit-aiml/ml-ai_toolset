output "cluster_name" { value = google_container_cluster.observability.name }
output "region" { value = google_container_cluster.observability.location }
