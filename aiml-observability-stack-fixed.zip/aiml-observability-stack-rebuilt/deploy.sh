#!/usr/bin/env bash
set -euo pipefail

CLOUD=""
PROJECT=""
REGION="us-central1"
CLUSTER="aiml-observability"
MIN_NODES=2
MAX_NODES=5

while [[ $# -gt 0 ]]; do
  case "$1" in
    --cloud=*) CLOUD="${1#*=}" ;;
    --project=*) PROJECT="${1#*=}" ;;
    --region=*) REGION="${1#*=}" ;;
    --cluster=*) CLUSTER="${1#*=}" ;;
    --min-nodes=*) MIN_NODES="${1#*=}" ;;
    --max-nodes=*) MAX_NODES="${1#*=}" ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

if [[ "$CLOUD" != "gcp" ]]; then
  echo "Currently implemented: --cloud=gcp" >&2
  exit 2
fi
if [[ -z "$PROJECT" ]]; then
  echo "--project=<gcp-project-id> is required" >&2
  exit 2
fi

for bin in gcloud terraform kubectl helm; do
  command -v "$bin" >/dev/null || { echo "Missing required executable: $bin" >&2; exit 1; }
done

export TF_VAR_project_id="$PROJECT"
export TF_VAR_region="$REGION"
export TF_VAR_cluster_name="$CLUSTER"
export TF_VAR_min_nodes="$MIN_NODES"
export TF_VAR_max_nodes="$MAX_NODES"

terraform -chdir=terraform/gcp init
terraform -chdir=terraform/gcp apply -auto-approve

gcloud container clusters get-credentials "$CLUSTER" --region "$REGION" --project "$PROJECT"

./scripts/install-stack.sh

cat <<MSG

Deployment complete.

Grafana:
  kubectl -n observability port-forward svc/kube-prometheus-stack-grafana 3000:80
  open http://localhost:3000

Langfuse:
  kubectl -n langfuse port-forward svc/langfuse-web 3001:3000
  open http://localhost:3001

Check pods:
  kubectl get pods -A

Starter alerts:
  kubectl get prometheusrule -n observability
MSG
