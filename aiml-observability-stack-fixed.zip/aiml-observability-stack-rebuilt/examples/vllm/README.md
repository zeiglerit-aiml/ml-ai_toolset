# vLLM

Expose the vLLM Prometheus endpoint and create a ServiceMonitor/PodMonitor for it. Recommended dashboard signals: running requests, waiting requests, KV-cache utilization, prompt/generation tokens, TTFT, end-to-end request latency, throughput, HTTP errors, GPU utilization and GPU memory.
