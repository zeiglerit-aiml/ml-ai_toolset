# MLflow

Instrument the service around MLflow model serving and training with OTEL/Prometheus. Track model family/version, request/prediction counts, inference latency, errors, model load latency, training duration, evaluation metrics, promotion/rollback events, and drift/data-quality measurements.
