# LangGraph / agent instrumentation contract

Emit spans for the graph run and important nodes, and attach dimensions such as `agent.name`, `graph.node`, `tool.name`, `model.name`, `retrieval.backend`, `dataset.id`, and outcome/error status. Export OTLP to `otel-opentelemetry-collector.observability.svc.cluster.local:4317`.

Recommended measurements:

- graph runs / successes / failures
- graph duration and node duration
- retries and checkpoint restores
- LLM calls, tokens, cost, TTFT
- MCP tool call count / error / latency
- retrieval latency and result count
- human approval wait time
- evaluation/quality score
