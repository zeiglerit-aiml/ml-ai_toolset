from time import perf_counter
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from prometheus_client import Counter, Histogram, make_asgi_app

app = FastAPI(title="Observable AI/ML Model Service")

PREDICTIONS = Counter("model_predictions_total", "Model prediction calls", ["model", "version"])
PREDICTION_ERRORS = Counter("model_prediction_errors_total", "Model prediction errors", ["model", "version"])
PREDICTION_LATENCY = Histogram("model_prediction_seconds", "Prediction latency", ["model", "version"])
AGENT_TOOL_CALLS = Counter("agent_tool_calls_total", "Agent tool calls", ["agent", "tool"])
AGENT_TOOL_ERRORS = Counter("agent_tool_errors_total", "Agent tool errors", ["agent", "tool"])
AGENT_RUN_DURATION = Histogram("agent_run_duration_seconds", "Agent run duration", ["agent"])

app.mount("/metrics", make_asgi_app())

class PredictionRequest(BaseModel):
    features: list[float] = Field(min_length=1)


def get_model_health(model_name: str):
    return {"model": model_name, "version": "demo-v1", "status": "healthy"}


def predict(model_name: str, features: list[float]):
    version = "demo-v1"
    started = perf_counter()
    try:
        PREDICTIONS.labels(model=model_name, version=version).inc()
        return {"model": model_name, "version": version, "prediction": sum(features) / len(features)}
    except Exception:
        PREDICTION_ERRORS.labels(model=model_name, version=version).inc()
        raise
    finally:
        PREDICTION_LATENCY.labels(model=model_name, version=version).observe(perf_counter() - started)


@app.get("/models/{model_name}/health")
def model_health(model_name: str):
    return get_model_health(model_name)


@app.post("/models/{model_name}/predict")
def model_predict(model_name: str, request: PredictionRequest):
    try:
        return predict(model_name, request.features)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
