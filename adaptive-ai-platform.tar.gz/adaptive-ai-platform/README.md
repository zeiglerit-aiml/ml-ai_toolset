# Adaptive ML/AI Container Platform

Five runnable services that turn heterogeneous inputs into a selected, evaluated, and served ML/AI solution.

## Services

1. `data-structurer` — converts CSV, JSON, TXT, PDF, DOCX, images, audio, and video metadata/text into canonical JSON.
2. `solution-orchestrator` — accepts intent, profiles structured data, selects a compatible solution, and coordinates jobs.
3. `solution-worker` — trains/configures the selected solution. The included implementation trains classification, regression, clustering, or anomaly models.
4. `evaluator-registry` — evaluates artifacts, applies a gate, and records approved solutions.
5. `serving-gateway` — loads an approved solution and provides online or batch inference.

The selector is a module inside Container 2. It is not a sixth service.

## Quick start

```bash
cp .env.example .env
docker compose build
docker compose up -d
./scripts/demo.sh
```

Open API documentation:

- Structurer: http://localhost:8001/docs
- Orchestrator: http://localhost:8002/docs
- Worker: http://localhost:8003/docs
- Evaluator: http://localhost:8004/docs
- Gateway: http://localhost:8005/docs

## End-to-end API flow

Structure a CSV already mounted in `/workspace/raw`:

```bash
curl -X POST http://localhost:8001/structure \
  -H 'Content-Type: application/json' \
  -d '{"source_uri":"/workspace/raw/customers.csv"}'
```

Create a solution plan:

```bash
curl -X POST http://localhost:8002/plan \
  -H 'Content-Type: application/json' \
  -d '{
    "dataset_uri":"/workspace/structured/customers.jsonl",
    "problem_statement":"Predict which customers will churn",
    "target_column":"churned"
  }'
```

Run the returned plan:

```bash
curl -X POST http://localhost:8003/train \
  -H 'Content-Type: application/json' \
  -d @workspace/plans/latest.json
```

Evaluate and register:

```bash
curl -X POST http://localhost:8004/evaluate \
  -H 'Content-Type: application/json' \
  -d '{"bundle_uri":"/workspace/bundles/latest","minimum_score":0.60}'
```

Predict:

```bash
curl -X POST http://localhost:8005/predict/customer-churn \
  -H 'Content-Type: application/json' \
  -d '{"records":[{"usage_score":0.2,"support_calls":5,"engagement_score":0.1}]}'
```

## Small and batch modes

- Online APIs accept small requests.
- `/batch` endpoints accept artifact URIs and write results back to shared/object storage.
- In Compose, `/workspace` is a shared volume.
- In Kubernetes, replace it with S3/GCS/Azure adapters or a PVC.
- `solution-worker` is normally launched as a Kubernetes Job, not kept running.

```bash
kubectl apply -f k8s/platform.yaml
kubectl create job --from=cronjob/solution-worker solution-worker-run-001
```

## Production extensions

The runnable reference implementation deliberately keeps optional heavyweight extractors behind adapters. Add OCR (Tesseract/cloud OCR), speech-to-text (Whisper/cloud speech), video frame extraction (FFmpeg), vLLM, Triton, Ray/Spark, and cloud object-store adapters without changing the service contracts.

