#!/usr/bin/env bash
set -euo pipefail
mkdir -p workspace/raw workspace/structured workspace/plans workspace/bundles workspace/registry
printf 'usage_score,support_calls,engagement_score,churned\n0.1,5,0.2,1\n0.9,0,0.8,0\n0.2,4,0.1,1\n0.8,1,0.9,0\n0.3,6,0.2,1\n0.7,1,0.8,0\n0.15,7,0.1,1\n0.85,0,0.9,0\n0.25,5,0.3,1\n0.75,1,0.7,0\n' > workspace/raw/customers.csv
curl -fsS -X POST localhost:8001/structure -H 'Content-Type: application/json' -d '{"source_uri":"/workspace/raw/customers.csv"}'
curl -fsS -X POST localhost:8002/plan -H 'Content-Type: application/json' -d '{"dataset_uri":"/workspace/structured/customers.jsonl","problem_statement":"Predict churn","target_column":"churned"}' > workspace/plans/latest.json
curl -fsS -X POST localhost:8003/train -H 'Content-Type: application/json' -d @workspace/plans/latest.json
curl -fsS -X POST localhost:8004/evaluate -H 'Content-Type: application/json' -d '{"bundle_uri":"/workspace/bundles/latest","minimum_score":0.0}'
echo

