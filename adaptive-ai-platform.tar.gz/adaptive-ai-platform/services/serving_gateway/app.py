import json
from pathlib import Path
import joblib, pandas as pd
from fastapi import FastAPI, HTTPException
from shared.contracts import PredictRequest

app = FastAPI(title="Container 5 - Universal Serving Gateway")


@app.post("/predict/{solution_id}")
def predict(solution_id: str, req: PredictRequest):
    index = Path("/workspace/registry/index.json")
    registry = json.loads(index.read_text()) if index.exists() else {}
    if solution_id not in registry: raise HTTPException(404, "Approved solution not found")
    bundle = joblib.load(Path(registry[solution_id]) / "model.joblib")
    frame = pd.get_dummies(pd.DataFrame(req.records)).reindex(columns=bundle["columns"], fill_value=0)
    result = bundle["model"].predict(frame).tolist()
    return {"solution_id": solution_id, "problem_type": bundle["problem_type"], "results": result}


@app.post("/batch/{solution_id}")
def batch(solution_id: str, input_uri: str, output_uri: str):
    rows = [json.loads(x) for x in Path(input_uri).read_text().splitlines()]
    result = predict(solution_id, PredictRequest(records=rows))
    Path(output_uri).write_text("\n".join(json.dumps({"result": x}) for x in result["results"]))
    return {"status": "completed", "output_uri": output_uri, "count": len(rows)}


@app.get("/health")
def health(): return {"status": "healthy"}

