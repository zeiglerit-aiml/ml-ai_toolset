import json, os, uuid
from pathlib import Path
import yaml
from fastapi import FastAPI
from shared.contracts import PlanRequest, SolutionPlan

app = FastAPI(title="Container 2 - Solution Orchestrator")


def infer(req: PlanRequest, rows: list[dict]):
    text = (req.problem_statement or "").lower()
    if any(x in text for x in ["anomal", "unusual", "fraud"]): return "anomaly_detection", .92
    if any(x in text for x in ["cluster", "segment", "group"]): return "clustering", .92
    if any(x in text for x in ["forecast", "predict value", "amount", "price"]): return "regression", .82
    if any(x in text for x in ["question", "search documents", "rag"]): return "question_answering", .90
    if req.target_column:
        values = {str(r.get("content", {}).get(req.target_column)) for r in rows[:100]}
        return ("binary_classification" if len(values) == 2 else "multiclass_classification"), .80
    return "clustering", .45


@app.post("/plan", response_model=SolutionPlan)
def plan(req: PlanRequest):
    rows = [json.loads(x) for x in Path(req.dataset_uri).read_text().splitlines() if x.strip()]
    task, confidence = infer(req, rows)
    catalog = yaml.safe_load(Path(os.getenv("MODEL_CATALOG", "/app/config/model-catalog.yaml")).read_text())["models"]
    candidates = [m["id"] for m in catalog if task in m["tasks"]]
    if not candidates: candidates = ["human-review-required"]
    execution = "batch" if len(rows) >= 100_000 else "small"
    result = SolutionPlan(problem_id=str(uuid.uuid4()), dataset_uri=req.dataset_uri, problem_type=task, target_column=req.target_column, selected_model=candidates[0], alternatives=candidates[1:], execution_mode=execution, confidence=confidence, reason=f"Intent and schema matched {task}; {len(rows)} structured records detected")
    dest = Path("/workspace/plans/latest.json"); dest.parent.mkdir(parents=True, exist_ok=True); dest.write_text(result.model_dump_json(indent=2))
    return result


@app.get("/health")
def health(): return {"status": "healthy"}

