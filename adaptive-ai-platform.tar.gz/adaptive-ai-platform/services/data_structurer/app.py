import csv, hashlib, json, mimetypes
from pathlib import Path
from fastapi import FastAPI, HTTPException
from docx import Document
from pypdf import PdfReader
from PIL import Image
from shared.contracts import StructureRequest

app = FastAPI(title="Container 1 - Universal Data Structurer")


def extract(path: Path):
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open(newline="", encoding="utf-8") as f:
            return list(csv.DictReader(f)), "tabular"
    if suffix in {".json", ".jsonl"}:
        text = path.read_text(encoding="utf-8")
        data = [json.loads(x) for x in text.splitlines()] if suffix == ".jsonl" else json.loads(text)
        return data if isinstance(data, list) else [data], "structured"
    if suffix in {".txt", ".md"}:
        return [{"text": path.read_text(encoding="utf-8")}], "text"
    if suffix == ".pdf":
        return [{"page": i + 1, "text": p.extract_text() or ""} for i, p in enumerate(PdfReader(path).pages)], "document"
    if suffix == ".docx":
        doc = Document(path)
        return [{"text": "\n".join(p.text for p in doc.paragraphs)}], "document"
    if suffix in {".png", ".jpg", ".jpeg"}:
        with Image.open(path) as im:
            return [{"width": im.width, "height": im.height, "mode": im.mode, "ocr_text": None}], "image"
    if suffix in {".wav", ".mp3", ".m4a", ".mp4", ".mov"}:
        return [{"transcript": None, "extractor_required": "speech/video adapter"}], "audio_video"
    raise ValueError(f"Unsupported extension: {suffix}")


@app.post("/structure")
def structure(req: StructureRequest):
    path = Path(req.source_uri)
    if not path.exists():
        raise HTTPException(404, "Source not found")
    records, modality = extract(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    out = Path(req.destination_uri or f"/workspace/structured/{path.stem}.jsonl")
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8") as f:
        for i, content in enumerate(records):
            f.write(json.dumps({"record_id": f"{digest[:12]}-{i}", "source": {"uri": str(path), "sha256": digest, "content_type": mimetypes.guess_type(path)[0]}, "modality": modality, "content": content}) + "\n")
    return {"status": "completed", "dataset_uri": str(out), "records": len(records), "modality": modality}


@app.get("/health")
def health(): return {"status": "healthy"}

