import json
from pathlib import Path
import joblib, pandas as pd
from fastapi import FastAPI, HTTPException
from sklearn.ensemble import IsolationForest, RandomForestClassifier, RandomForestRegressor
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score, r2_score, silhouette_score
from sklearn.model_selection import train_test_split
from shared.contracts import TrainRequest

app = FastAPI(title="Container 3 - Adaptive Solution Worker")


@app.post("/train")
def train(req: TrainRequest):
    raw = [json.loads(x)["content"] for x in Path(req.dataset_uri).read_text().splitlines() if x.strip()]
    frame = pd.DataFrame(raw).apply(pd.to_numeric, errors="ignore")
    bundle = Path(f"/workspace/bundles/{req.problem_id}"); bundle.mkdir(parents=True, exist_ok=True)
    score = 0.0
    if req.problem_type in {"binary_classification", "multiclass_classification", "regression"}:
        if not req.target_column or req.target_column not in frame: raise HTTPException(400, "A valid target_column is required")
        y = frame.pop(req.target_column); X = pd.get_dummies(frame).fillna(0)
        Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=.2, random_state=42)
        model = RandomForestRegressor(random_state=42) if req.problem_type == "regression" else RandomForestClassifier(random_state=42)
        model.fit(Xtr, ytr); pred = model.predict(Xte)
        score = r2_score(yte, pred) if req.problem_type == "regression" else accuracy_score(yte, pred)
    elif req.problem_type == "anomaly_detection":
        X = pd.get_dummies(frame).fillna(0); model = IsolationForest(random_state=42).fit(X); score = 1.0
    elif req.problem_type == "clustering":
        X = pd.get_dummies(frame).fillna(0); model = KMeans(n_clusters=min(3, len(X)), random_state=42).fit(X); score = silhouette_score(X, model.labels_) if len(set(model.labels_)) > 1 else 0.0
    else: raise HTTPException(501, "This catalog adapter requires an external AI runtime")
    joblib.dump({"model": model, "columns": list(X.columns), "problem_type": req.problem_type}, bundle / "model.joblib")
    manifest = {"problem_id": req.problem_id, "model": req.selected_model, "score": float(score), "bundle_uri": str(bundle)}
    (bundle / "manifest.json").write_text(json.dumps(manifest, indent=2)); Path("/workspace/bundles/latest").unlink(missing_ok=True); Path("/workspace/bundles/latest").symlink_to(bundle, target_is_directory=True)
    return manifest


@app.get("/health")
def health(): return {"status": "healthy"}

