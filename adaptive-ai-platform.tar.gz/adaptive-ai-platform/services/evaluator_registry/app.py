import json, shutil
from pathlib import Path
from fastapi import FastAPI
from shared.contracts import EvaluateRequest

app = FastAPI(title="Container 4 - Evaluator and Registry")


@app.post("/evaluate")
def evaluate(req: EvaluateRequest):
    bundle = Path(req.bundle_uri).resolve(); manifest = json.loads((bundle / "manifest.json").read_text())
    approved = manifest["score"] >= req.minimum_score
    if approved:
        dest = Path("/workspace/registry") / manifest["problem_id"] / "1"; dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists(): shutil.rmtree(dest)
        shutil.copytree(bundle, dest)
        index = Path("/workspace/registry/index.json"); data = json.loads(index.read_text()) if index.exists() else {}
        data[manifest["problem_id"]] = str(dest); index.write_text(json.dumps(data, indent=2))
    return {"decision": "approved" if approved else "rejected", "score": manifest["score"], "minimum_score": req.minimum_score, "solution_id": manifest["problem_id"]}


@app.get("/health")
def health(): return {"status": "healthy"}

