# Runtime architecture

The platform exchanges large data through object storage or the shared development volume. APIs and events carry identifiers and URIs, not binary payloads.

## Persistent control plane

- `solution-orchestrator`: intent, planning, model catalog, job state, retries, and approval routing.
- `serving-gateway`: stable API that resolves registered solution runtimes.

## Event- or job-driven data plane

- `data-structurer`: one object, manifest, bucket prefix, or batch per run.
- `solution-worker`: CPU, GPU, batch, or distributed job selected by the plan.
- `evaluator-registry`: evaluates a completed bundle and promotes it when gates pass.

## Durable contracts

- Structured data: JSONL records with source lineage.
- Solution plan: task, selected adapter, alternatives, scale, and confidence.
- Solution bundle: model plus preprocessing, schema, metrics, and manifest.
- Registry entry: approved immutable solution version and runtime metadata.
- Serving result: solution identity, problem type, execution metadata, and result.

Production deployments replace the shared volume with S3, GCS, Azure Blob, or another object store, and use a queue such as Kafka, SQS, Pub/Sub, or Service Bus to deliver state-change events.

