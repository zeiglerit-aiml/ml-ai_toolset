from typing import Any
from pydantic import BaseModel, Field


class StructureRequest(BaseModel):
    source_uri: str
    destination_uri: str | None = None


class PlanRequest(BaseModel):
    dataset_uri: str
    problem_statement: str | None = None
    target_column: str | None = None
    preferred_metric: str | None = None


class SolutionPlan(BaseModel):
    problem_id: str
    dataset_uri: str
    problem_type: str
    target_column: str | None = None
    selected_model: str
    alternatives: list[str] = []
    execution_mode: str
    confidence: float = Field(ge=0, le=1)
    reason: str


class TrainRequest(SolutionPlan):
    pass


class EvaluateRequest(BaseModel):
    bundle_uri: str
    minimum_score: float = 0.60


class PredictRequest(BaseModel):
    records: list[dict[str, Any]]

