# Architecture Notes

The public API is stable while routing and model composition can evolve independently.

- **Single**: one registered model produces the answer.
- **Multi**: several models execute; each output is returned independently.
- **Ensemble**: several compatible models contribute to one output.
- **Auto**: policy selects one of the above based on modality, task, latency, confidence, registry metadata and later drift/cost signals.

Cloud portability is maintained with adapters. Kubernetes is the serving substrate; GKE is the preferred GCP implementation, while EKS/AKS/on-prem remain possible.
