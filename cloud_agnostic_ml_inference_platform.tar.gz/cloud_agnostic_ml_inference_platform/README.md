# Cloud-Agnostic ML Inference Platform

Python-first reference architecture for:
- broad data ingestion: API/HTTP, CSV/TSV, JSON/JSONL, Parquet, SQL/MySQL-compatible DBs, images/handwriting, GCS, S3-compatible object stores, Databricks SQL
- one `/predict` API surface
- single-model, multi-model, ensemble, or automatic routing
- continuous train/evaluate/register/deploy/observe/retrain lifecycle
- Kubernetes serving (GKE first, portable to EKS/AKS/on-prem)
- Jupyter exploration without making notebooks the production control plane

## Architecture

```text
 DATA SOURCES / INPUTS
 ┌──────────────────────────────────────────────────────────────────────┐
 │ REST/API │ CSV/TSV │ JSON/JSONL │ Parquet │ SQL/MySQL │ Images/OCR │
 │ GCS      │ S3-compatible object storage │ Databricks SQL           │
 └───────────────────────────────┬──────────────────────────────────────┘
                                 ▼
                    Python Input Adapter Layer
                                 │
                                 ▼
                  Validate / Normalize / Features
                                 │
                                 ▼
                        Task / Modality Detector
                                 │
                                 ▼
                    Inference Policy + Router
                    ┌────────────┼────────────┐
                    ▼            ▼            ▼
                  SINGLE        MULTI       ENSEMBLE
                    │          M1 M2 M3     M1 M2 M3
                    │            │            │
                    │            │       vote/avg/stack
                    └────────────┴────────────┘
                                 ▼
                         Unified Response
                                 │
                                 ▼
                    Metrics / Drift / Feedback
                                 │
                                 ▼
             Retrain → Evaluate → Register → CI/CD
                                 │
                                 ▼
                     Container → Kubernetes
                      GKE / EKS / AKS / K8s
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open `notebooks/ml_pipeline_workbench.ipynb` for an interactive walkthrough.

## Example

POST `/predict` with JSON:
```json
{
  "strategy": "auto",
  "task": "classification",
  "records": [[5.1, 3.5, 1.4, 0.2]]
}
```

This repo is a runnable reference scaffold. Cloud/database adapters require credentials and endpoints supplied by environment variables.
