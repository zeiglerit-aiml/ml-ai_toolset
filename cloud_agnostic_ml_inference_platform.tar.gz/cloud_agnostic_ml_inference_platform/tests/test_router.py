from app.routing.router import route

def test_fast_auto_is_single():
    assert route("auto", latency_ms=20).strategy == "single"

def test_high_confidence_is_ensemble():
    assert route("auto", confidence="high").strategy == "ensemble"

def test_multi_is_not_ensemble():
    assert route("multi").strategy == "multi"
