"""Inference decision layer.

This router intentionally starts deterministic rather than using another ML model.
That makes routing explainable, testable and safe to operate. A learned router can
later replace `auto_plan()` without changing the endpoint contract.
"""
from dataclasses import dataclass

@dataclass
class Plan:
    strategy: str
    models: list[str]
    ensemble_method: str | None = None
    reason: str = ""

APPROVED = ["logistic", "random_forest", "gradient_boosting"]

def route(strategy="auto", modality="tabular", latency_ms=250,
          confidence="normal", requested_models=None) -> Plan:
    requested_models = requested_models or APPROVED

    # Images/handwriting need a registered vision/OCR capability. We do not
    # pretend a tabular sklearn model can process pixels.
    if modality in {"image", "handwriting"}:
        return Plan("single", ["ocr_or_vision_model"],
                    reason="Image modality requires the vision/OCR model family.")

    if strategy == "single":
        return Plan("single", [requested_models[0]], reason="Caller selected single.")
    if strategy == "multi":
        return Plan("multi", requested_models, reason="Caller requested independent outputs.")
    if strategy == "ensemble":
        return Plan("ensemble", requested_models, "soft_vote",
                    "Caller requested one combined prediction.")

    # AUTO POLICY:
    # Very tight latency -> one inexpensive model invocation.
    if latency_ms <= 30:
        return Plan("single", ["logistic"],
                    reason="Tight latency budget favors a single fast model.")

    # High-confidence requests get diversity: several approved models contribute
    # probabilities to one final prediction.
    if confidence == "high":
        return Plan("ensemble", requested_models, "soft_vote",
                    "High-confidence policy uses a diverse probability ensemble.")

    # Normal auto mode runs multiple models independently. This is multi-model
    # serving, NOT ensemble learning, because outputs remain separate.
    return Plan("multi", requested_models,
                reason="Normal auto policy exposes independent model predictions.")
