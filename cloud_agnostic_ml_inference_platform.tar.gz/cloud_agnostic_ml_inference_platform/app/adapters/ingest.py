"""Cloud/data-format adapters.

Formats and locations are deliberately separate:
- format: CSV, JSON, Parquet, image, etc.
- source: local upload, HTTP API, SQL, GCS, S3, Databricks, etc.
"""
from __future__ import annotations
import io, json
from pathlib import Path
import pandas as pd
import requests
from PIL import Image

def from_csv(path_or_buffer, sep=","):
    return pd.read_csv(path_or_buffer, sep=sep)

def from_tsv(path_or_buffer):
    return pd.read_csv(path_or_buffer, sep="\t")

def from_json(path_or_buffer, lines=False):
    return pd.read_json(path_or_buffer, lines=lines)

def from_parquet(path_or_buffer):
    return pd.read_parquet(path_or_buffer)

def from_http(url: str, fmt: str = "json"):
    """Pull machine-readable data from a REST/API endpoint."""
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    if fmt == "json":
        payload = r.json()
        return pd.json_normalize(payload if isinstance(payload, list) else [payload])
    if fmt == "csv":
        return pd.read_csv(io.StringIO(r.text))
    raise ValueError(f"Unsupported HTTP format: {fmt}")

def from_sql(connection_url: str, query: str):
    """Works with SQLAlchemy-supported DBs; MySQL uses mysql+pymysql://..."""
    from sqlalchemy import create_engine
    engine = create_engine(connection_url)
    return pd.read_sql(query, engine)

def from_gcs(bucket: str, blob: str, fmt="parquet"):
    from google.cloud import storage
    client = storage.Client()
    raw = client.bucket(bucket).blob(blob).download_as_bytes()
    return _bytes_to_frame(raw, fmt)

def from_s3(bucket: str, key: str, fmt="parquet", endpoint_url=None):
    """AWS S3 or an S3-compatible object store."""
    import boto3
    client = boto3.client("s3", endpoint_url=endpoint_url)
    raw = client.get_object(Bucket=bucket, Key=key)["Body"].read()
    return _bytes_to_frame(raw, fmt)

def from_databricks(server_hostname: str, http_path: str, token: str, query: str):
    """Databricks SQL Warehouse ingestion."""
    from databricks import sql
    with sql.connect(server_hostname=server_hostname,
                     http_path=http_path,
                     access_token=token) as conn:
        with conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description]
    return pd.DataFrame(rows, columns=cols)

def from_image(path_or_bytes):
    """Images/handwriting stay as image objects until a vision/OCR preprocessor runs."""
    if isinstance(path_or_bytes, (bytes, bytearray)):
        return Image.open(io.BytesIO(path_or_bytes)).convert("RGB")
    return Image.open(path_or_bytes).convert("RGB")

def _bytes_to_frame(raw: bytes, fmt: str):
    b = io.BytesIO(raw)
    if fmt == "parquet":
        return pd.read_parquet(b)
    if fmt == "csv":
        return pd.read_csv(b)
    if fmt in ("json", "jsonl"):
        return pd.read_json(b, lines=(fmt == "jsonl"))
    raise ValueError(f"Unsupported object format: {fmt}")
