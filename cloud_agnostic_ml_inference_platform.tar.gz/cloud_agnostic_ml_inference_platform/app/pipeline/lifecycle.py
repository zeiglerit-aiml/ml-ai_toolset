"""A compact Python ML lifecycle controller.

Production CI/CD should call these Python stages; Kubernetes/cloud infrastructure
remains declarative rather than being hidden inside notebook cells.
"""
from app.models.train import train_models

def run_training_pipeline():
    metrics = train_models()
    # Add: schema/data validation
    # Add: quality gates against previous registered model
    # Add: model registry publication
    # Add: drift/feedback-triggered retraining
    return {"status": "trained", "metrics": metrics}

if __name__ == "__main__":
    print(run_training_pipeline())
