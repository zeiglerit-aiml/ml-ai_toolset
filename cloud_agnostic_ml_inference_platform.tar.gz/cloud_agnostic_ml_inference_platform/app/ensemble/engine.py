import numpy as np

def soft_vote(probabilities, weights=None):
    """Average class probabilities; optional weights can reflect validated model quality."""
    p = np.asarray(probabilities)
    if weights is None:
        return p.mean(axis=0)
    w = np.asarray(weights, dtype=float)
    w /= w.sum()
    return np.tensordot(w, p, axes=(0, 0))
