from pathlib import Path
from typing import Literal
import joblib
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.routing.router import route
from app.ensemble.engine import soft_vote
from app.models.train import train_models, MODEL_DIR

app = FastAPI(title="Cloud-Agnostic ML Inference Platform", version="0.1.0")

class PredictRequest(BaseModel):
    strategy: Literal["auto", "single", "multi", "ensemble"] = "auto"
    task: str = "classification"
    modality: Literal["tabular", "image", "handwriting"] = "tabular"
    records: list[list[float]] = Field(default_factory=list)
    latency_ms: int = 250
    confidence: Literal["normal", "high"] = "normal"
    models: list[str] | None = None

def ensure_models():
    if not (MODEL_DIR / "logistic.joblib").exists():
        train_models()

def load_model(name):
    path = MODEL_DIR / f"{name}.joblib"
    if not path.exists():
        raise HTTPException(404, f"Model not registered: {name}")
    return joblib.load(path)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict")
def predict(req: PredictRequest):
    """One API surface can dispatch single, multi-model, or ensemble inference."""
    if req.modality != "tabular":
        raise HTTPException(
            501,
            "Vision/OCR adapter is scaffolded; register a vision model before serving images."
        )
    if not req.records:
        raise HTTPException(400, "records is required for tabular inference")

    ensure_models()
    plan = route(req.strategy, req.modality, req.latency_ms,
                 req.confidence, req.models)

    models = {name: load_model(name) for name in plan.models}
    X = np.asarray(req.records, dtype=float)

    if plan.strategy == "single":
        name, model = next(iter(models.items()))
        return {
            "strategy": "single", "model": name,
            "prediction": model.predict(X).tolist(),
            "reason": plan.reason
        }

    if plan.strategy == "multi":
        return {
            "strategy": "multi",
            "predictions": {n: m.predict(X).tolist() for n, m in models.items()},
            "reason": plan.reason
        }

    # ENSEMBLE: combine probabilities from all participating classifiers.
    probs = [m.predict_proba(X) for m in models.values()]
    combined = soft_vote(probs)
    return {
        "strategy": "ensemble",
        "models": list(models),
        "prediction": combined.argmax(axis=1).tolist(),
        "probabilities": combined.tolist(),
        "method": plan.ensemble_method,
        "reason": plan.reason
    }
