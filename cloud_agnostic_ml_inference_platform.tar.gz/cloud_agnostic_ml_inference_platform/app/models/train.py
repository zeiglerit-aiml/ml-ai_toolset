from pathlib import Path
import joblib
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

MODEL_DIR = Path(__file__).resolve().parents[2] / "artifacts"
MODEL_DIR.mkdir(exist_ok=True)

def train_models():
    X, y = load_iris(return_X_y=True)
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=.25, random_state=42, stratify=y
    )

    models = {
        "logistic": LogisticRegression(max_iter=1000),
        "random_forest": RandomForestClassifier(n_estimators=150, random_state=42),
        "gradient_boosting": GradientBoostingClassifier(random_state=42),
    }

    metrics = {}
    for name, model in models.items():
        model.fit(Xtr, ytr)
        metrics[name] = accuracy_score(yte, model.predict(Xte))
        joblib.dump(model, MODEL_DIR / f"{name}.joblib")

    return metrics

if __name__ == "__main__":
    print(train_models())
